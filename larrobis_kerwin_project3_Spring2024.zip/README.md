Name: Kerwin Larrobis
Section: Class #10605
UFL email: kerwinlarrobis@ufl.edu
System: x64-based PC
Compiler: GCC 7.3.0 (MinGW 64-bit)
SFML version: SFML 2.5.1
IDE: CLion
Other notes:
I tried to organize my classes at first then Board.h kept getting bigger and bigger I am so sorry for the mess