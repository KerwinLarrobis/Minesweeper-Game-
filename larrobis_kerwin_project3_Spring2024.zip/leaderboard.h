//
// Created by kerwi on 4/9/2025.
//
#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <SFML/Graphics.hpp>
#include <cctype>
using namespace std;
#ifndef LEADERBOARD_H
#define LEADERBOARD_H

class leaderboard {
private:
    sf::RenderWindow window;
    sf::Font font;
    sf::Text title;
    sf::Text rankings;
    sf::Color color;
    int rowCount;
    int colCount;
    int height;
    int width;
public:
    void setText(sf::Text &text, float x, float y){
        sf::FloatRect textRect = text.getLocalBounds();
        text.setOrigin(textRect.left + textRect.width/2.0f,textRect.top + textRect.height/2.0f);
        text.setPosition(sf::Vector2f(x, y));
    }

    leaderboard(int row, int col) {
        rowCount = row;
        colCount = col;
        height = rowCount * 16 + 50;
        width = colCount * 16;
        window.create(sf::VideoMode(width, height), "Leaderboard Window");
        font.loadFromFile("files/font.ttf");
        title.setFont(font);
        title.setString("LEADERBOARD");
        title.setStyle(sf::Text::Bold | sf::Text::Underlined);
        title.setCharacterSize(20);
        title.setFillColor(sf::Color::White);
        setText(title, width / 2, height / 2 - 120);

        ifstream leaderboard("files/leaderboard.txt");
        string line;
        vector<string> lines;
        while (getline(leaderboard, line)) {
            stringstream ss(line);
            string time;
            string name;

            getline(ss, time, ',');
            getline(ss, name);
            name = name.substr(1);

            lines.push_back(time);
            lines.push_back(name);
        }
        rankings.setFont(font);
        rankings.setString("1.\t" + lines[0] + "\t" + lines[1] +
            "\n\n2.\t" + lines[2] + "\t" + lines[3] +
            "\n\n3.\t" + lines[4] + "\t" + lines[5] +
            "\n\n4.\t" + lines[6] + "\t" + lines[7] +
            "\n\n5.\t" + lines[8] + "\t" + lines[9]);
        rankings.setStyle(sf::Text::Bold);
        rankings.setCharacterSize(18);
        rankings.setFillColor(sf::Color::White);
        setText(rankings, width / 2, height / 2 + 20);
    }

    void run() {
        while(window.isOpen()) {
            sf::Event event;
            while(window.pollEvent(event)) {
                if(event.type == sf::Event::Closed) {
                    window.close();
                }
            }
            window.clear(sf::Color::Blue);
            window.draw(title);
            window.draw(rankings);
            window.display();
        }
    }
};



#endif //LEADERBOARD_H
